<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editproject?id=').$before->id; ?>">Product Details</a></li>
<li><a href="<?php echo site_url('site/viewprojectimage?id=').$before->id; ?>">Images</a></li>
<li><a href="<?php echo site_url('site/viewprojectdatapoint?id=').$before->id; ?>">Data Points</a></li>
<li><a href="<?php echo site_url('site/viewprojectenquiry?id=').$before->id; ?>">Enquiry</a></li>
</ul>
</div>
</section>