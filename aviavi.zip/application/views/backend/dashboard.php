<div class="row">
    <div class="col-md-3">
        <div class="well">
            <b>Number of new Registered Users added</b>
        </div>
        <div class="row state-overview">
            <div class="col-lg-12 col-sm-12">
                <section class="panel">
                    <div class="symbol terques">
                        <i class="icon-user"></i>
                    </div>
                        <div class="value">
                            <p>Registered Users</p>
                            <h1><?php echo $newregisteredusers;?></h1>

                        </div>
                </section>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="well">
            <b>Number of new Registered Users added</b>
        </div>
        <div class="row state-overview">
            <div class="col-lg-12 col-sm-12">
                <section class="panel">
                    <div class="symbol terques">
                        <i class="icon-user"></i>
                    </div>
                        <div class="value">
                            <p>Registered Users</p>
                            <h1><?php echo "hello";?></h1>

                        </div>
                </section>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="well">
            <b>Number of new Registered Users added</b>
        </div>
        <div class="row state-overview">
            <div class="col-lg-12 col-sm-12">
                <section class="panel">
                    <div class="symbol terques">
                        <i class="icon-user"></i>
                    </div>
                        <div class="value">
                            <p>Registered Users</p>
                            <h1><?php echo "hello";?></h1>

                        </div>
                </section>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="well">
            <b>Number of new Registered Users added</b>
        </div>
        <div class="row state-overview">
            <div class="col-lg-12 col-sm-12">
                <section class="panel">
                    <div class="symbol terques">
                        <i class="icon-user"></i>
                    </div>
                        <div class="value">
                            <p>Registered Users</p>
                            <h1><?php echo "hello";?></h1>

                        </div>
                </section>
            </div>
        </div>
    </div>
</div>